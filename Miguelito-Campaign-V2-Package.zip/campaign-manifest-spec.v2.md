# Manifesto da campanha didática — especificação revisada

Este documento acompanha `campaign-manifest.v2.js` e consolida progressão, tutorial, pools, patógenos, desbloqueios, segmentos e provas finais.

## Princípio pedagógico irrenunciável

Um organismo novo deve ser explicado **na primeira vez em que aparece**:

```text
primeira aparição real
→ cartão obrigatório imediatamente
```

A supressão espacial nunca pode permitir que um organismo apareça sem explicação. Se isso ocorrer por erro de geração, o cartão ignora a trava, abre imediatamente e registra diagnóstico.

## Campanha híbrida

```text
módulo fixo de introdução
→ prática procedural
→ segundo módulo fixo, quando necessário
→ desafio procedural ampliado
→ prova final
```

Somente primeiro encontro, demonstrações difíceis, desbloqueios e provas são autorais. O restante permanece procedural.

## Cinco proteções complementares

### 1. Pool por fase e chunk

Usar `getProceduralPoolAt(phase, chunkIndex)`. Um organismo vagante só entra no procedural após `poolFromChunk`.

### 2. Tethering na estreia

O organismo vagante da estreia permanece perto da cena até o cartão ser visto. Evitar dependência circular: injetar `hasSeenCard` ou usar estado compartilhado simples.

### 3. Apresentações agrupadas

Uma apresentação pode absorver vários gatilhos. Só `autoOpenTrigger` abre o cartão. Os demais atualizam GUIA/progresso sem nova pausa quando `suppressIndividualCards` é verdadeiro.

### 4. Tutorial por segmento

- `guided`: cartões e sequência autoral permitidos;
- `silent`: registra no GUIA, mas não pausa;
- `disabled`: não registra nem apresenta automaticamente.

Organismo novo não explicado tem precedência sobre `silent`.

### 5. Supressão espacial como segurança

Depois de apresentação não obrigatória, aguardar aproximadamente 90% da largura visível ou 60 segundos:

```js
visibleWorldWidth = canvas.width / cameraZoom
minimumDistance = Math.max(600, visibleWorldWidth * 0.90)
```

Não aplicar a organismo novo nem a salto duplo, Dash ou Pulso.

## Poderes e geometria

Poder planejado para a fase não equivale a poder disponível no início. O gerador consulta `getAvailableUnlocksAt(phase, chunkIndex)`. O unlock do chunk N só pode ser exigido a partir de N+1.

Garantias:

- cristal somente em chunk com `pulse`;
- `pulse` somente depois do unlock;
- vão obrigatório de Dash somente depois do Dash;
- geometria obrigatória de salto duplo somente depois do salto duplo;
- ponte procedural somente depois de `mycorrhizaStructures`;
- raiz lateral procedural somente depois de `azospirillumRoots`.

## Organização da campanha

1. Prólogo — movimento e pulo.
2. Fase 1 — exsudato, recrutamento, Bacillus e biofilme.
3. Fase 2 — Rhizobium, nódulo e FBN.
4. Fase 3 — Azospirillum, raiz lateral e salto duplo.
5. Fase 4 — micorriza, arbúsculo, ponte e Dash.
6. Fase 5 — Pseudomonas, ferro, oportunista, Trichoderma e micoparasitismo.
7. Fase 6 — Rhizoctonia, saúde/recuperação e Pulso.
8. Fase 7 — Meloidogyne: J2, galha, fêmea, massa de ovos e sequela.
9. Fase 8 — síntese sem novos cartões automáticos.

Ralstonia fica para expansão pós-piloto.

## Ordem de Meloidogyne

```text
J2 → busca → penetração → migração → galha → fêmea → massa de ovos → eclosão
```

## Provas finais

As provas verificam estado real, não apenas cartão visto. Criar avaliador central de `{ type, key, operator, value }` e mapear as chaves abstratas ao estado real.

## Implementação por PRs

1. Manifesto, validador e testes, sem mudar comportamento.
2. Progressão e gating de habilidades.
3. Tutorial agrupado, modos e primeira aparição obrigatória.
4. Pool por chunk e tethering.
5. Fase 1 como corte vertical.
6. Uma fase por PR após playtest.
