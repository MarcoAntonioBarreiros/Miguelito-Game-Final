# Tarefa para o Codex — Campanha didática v2

## Segurança do repositório

Trabalhe apenas no repositório duplicado. Antes de escrever:

1. confirme a URL do alvo;
2. confirme que NÃO é `MarcoAntonioBarreiros/Miguelito-Game`;
3. leia `campaign-manifest.v2.js` e `campaign-manifest-spec.v2.md`;
4. confira IDs reais de cartões, organismos, flags e estados;
5. apresente incompatibilidades antes de adaptar.

Não altere conteúdo científico silenciosamente.

## Objetivo

Migrar para campanha híbrida dirigida por manifesto: módulos fixos curtos, desafios procedurais, estreia controlada, cartões agrupados e prova final.

## Regras obrigatórias

### Primeira aparição

Todo organismo novo abre seu cartão imediatamente. A trava espacial não pode silenciá-lo. Aparição inesperada deve:

- abrir cartão;
- ignorar cooldown;
- emitir `tutorialPacing.diagnosticEventName`;
- registrar fase, chunk, tipo, posição e pool.

### Cartões agrupados

Mapear `triggerIds` para uma apresentação. Quando `suppressIndividualCards` for verdadeiro, somente `autoOpenTrigger` abre; os demais atualizam GUIA/progresso.

### Modos

Consultar `getTutorialModeAt`:

- guided: pode pausar;
- silent: registra sem pausar;
- disabled: não registra automaticamente.

Organismo novo ainda não explicado tem precedência.

### Pacing

Aplicar somente a apresentações não obrigatórias, usando viewport real. Organismo novo e poderes ignoram a trava.

## Gerador

### Pool

Usar `getProceduralPoolAt(phase, chunkIndex)`.

### Patógenos

Usar `getPathogensAt(phase, chunkIndex)`.

### Habilidades

Usar `getAvailableUnlocksAt` e `getRequiredPracticeAbilityAt`. Preservar a garantia atual de que poder ausente não pode ser exigido.

Falhar em teste se houver:

- cristal antes do Pulso;
- vão de Dash antes do Dash;
- salto duplo obrigatório antes do unlock;
- ponte antes de `mycorrhizaStructures`;
- raiz lateral antes de `azospirillumRoots`.

## Blocos fixos

Segmento `fixed` deve aceitar geometria e entidades autorais, objetivo local, condição de conclusão e bloqueio de saída. Segmento `procedural` continua usando o gerador existente, limitado pelo manifesto.

## Provas finais

Criar avaliador central para `{ type, key, operator, value }`. Não concluir apenas porque cartão foi visto.

## Plano de PRs

### PR 1 — Manifesto e validação

Adicionar manifesto, validação e testes. Não mudar comportamento.

### PR 2 — Progressão e gating

Integrar perfil, unlocks, lógica e geometria. Testes determinísticos por seed.

### PR 3 — Tutorial

Agrupamento, modos, primeira aparição obrigatória, pacing e diagnóstico.

### PR 4 — Pool e tethering

Integrar pool por chunk, estreia e patógenos.

### PR 5 — Corte vertical da Fase 1

Implementar somente a Fase 1 completa e fazer playtest.

### PRs seguintes

Uma fase por PR. Não implementar tudo em um único PR.

## Entrega de cada PR

Informar arquivos, antes/depois, testes, limitações, screenshots/vídeo, riscos e instruções de playtest. Não fazer merge automático sem confirmação.
