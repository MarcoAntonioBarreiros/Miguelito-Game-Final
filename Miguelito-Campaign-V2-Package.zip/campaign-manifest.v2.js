// campaign-manifest.v2.js
// Fonte única de verdade da campanha didática "Beans for a Living Soil".
//
// Princípios obrigatórios:
// 1. Organismo novo: cartão obrigatório na PRIMEIRA aparição.
// 2. A supressão espacial nunca silencia organismo novo; é apenas pacing de segurança.
// 3. Organismos entram no procedural somente depois da zona de estreia.
// 4. Estruturas/processos relacionados são agrupados em uma única apresentação.
// 5. Poder previsto para a fase != poder já disponível naquele chunk.
// 6. Nenhum obstáculo/geometria pode exigir um poder ainda não desbloqueado.

export const ECOLOGY_ROAMING_TYPES = Object.freeze([
  'rhizobium', 'bacillus', 'azospirillum', 'pseudomonas', 'oportunista', 'trichoderma',
]);

export const PATHOGEN_SYSTEMS = Object.freeze(['rhizoctonia', 'meloidogyne', 'ralstonia']);
export const CAMPAIGN_UNLOCKS = Object.freeze([
  'doubleJump', 'dash', 'pulse', 'mycorrhizaStructures', 'azospirillumRoots',
]);
export const TUTORIAL_MODES = Object.freeze(['guided', 'silent', 'disabled']);
export const PRESENTATION_POLICIES = Object.freeze([
  'mandatory-first-appearance', 'event-immediate', 'guided-sequence', 'spaced-auto', 'silent-only',
]);

export const tutorialPacing = Object.freeze({
  distanceViewportFactor: 0.90,
  minimumWorldDistance: 600,
  fallbackSeconds: 60,
  organismFirstAppearanceBypassesSpatialGate: true,
  powerUnlockBypassesSpatialGate: true,
  diagnosticEventName: 'miguelito:tutorial-unexpected-first-appearance',
});

const phases = [
  {
    id: 'prologue', phase: 0, totalChunks: 16,
    title: 'Primeiros passos na rizosfera', theme: 'movimento',
    mission: 'Aprenda a se mover e a saltar; alcance a raiz principal.',
    newConcepts: ['movimento', 'plataforma-vs-queda'], newCommand: null,
    presentations: [{
      id: 'presentation-welcome', cardId: 'system-welcome',
      triggerIds: ['system-welcome'], autoOpenTrigger: 'system-welcome',
      policy: 'guided-sequence', suppressIndividualCards: false,
      debutChunk: 0, moduleId: 'p0-intro',
      pages: ['pausa', 'GUIA', 'como os cartões funcionam'],
    }],
    unlockEvents: [], pathogenDebuts: [],
    segments: [
      { id: 'p0-intro', kind: 'fixed', from: 0, to: 3, tutorialMode: 'guided',
        debutPresentationIds: ['presentation-welcome'], mechanicsRequired: [],
        beats: ['andar', 'parar', 'mudar de direção', 'câmera', 'pulo simples'] },
      { id: 'p0-challenge', kind: 'procedural', from: 4, to: 12, tutorialMode: 'silent',
        mechanicsRequired: [], beats: ['plataformas', 'desníveis', 'vãos', 'sem organismos'] },
      { id: 'p0-final', kind: 'final', from: 13, to: 15, tutorialMode: 'silent',
        mechanicsRequired: [], beats: ['três saltos', 'raiz principal'] },
    ],
    finalTest: { id: 'p0-test', goal: 'Entrar na raiz principal.', requires: [
      { type: 'worldState', key: 'reachedFinalRoot', operator: '===', value: true },
    ]},
    notes: [],
  },

  {
    id: 'phase-1', phase: 1, totalChunks: 40,
    title: 'Recrutar e estabelecer', theme: 'fundamentos',
    mission: 'Recrute Bacillus com exsudatos e forme o primeiro biofilme funcional.',
    newConcepts: ['exsudato→recrutamento→inoculação', 'Bacillus→biofilme'], newCommand: null,
    presentations: [
      { id: 'presentation-recruitment', cardId: 'action-exudate',
        triggerIds: ['action-exudate', 'action-inoculation'], autoOpenTrigger: 'action-exudate',
        policy: 'guided-sequence', suppressIndividualCards: true,
        debutChunk: 4, moduleId: 'p1-intro',
        pages: ['exsudato', 'atração/alimentação', 'recrutamento', 'inoculação'] },
      { id: 'presentation-bacillus', cardId: 'organism-bacillus',
        triggerIds: ['organism-bacillus', 'structure-biofilm'], autoOpenTrigger: 'organism-bacillus',
        policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        roamingType: 'bacillus', debutChunk: 6, poolFromChunk: 9,
        moduleId: 'p1-intro', tetherUntilSeen: true,
        pages: ['quem é', 'colonização', 'biofilme', 'proteção/checkpoint no jogo'] },
    ],
    unlockEvents: [], pathogenDebuts: [],
    segments: [
      { id: 'p1-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: [] },
      { id: 'p1-intro', kind: 'fixed', from: 4, to: 8, tutorialMode: 'guided',
        debutPresentationIds: ['presentation-recruitment', 'presentation-bacillus'],
        mechanicsRequired: ['exudate', 'inoculation'] },
      { id: 'p1-challenge', kind: 'procedural', from: 9, to: 34, tutorialMode: 'silent',
        mechanicsRequired: ['exudate', 'inoculation'] },
      { id: 'p1-final', kind: 'final', from: 35, to: 39, tutorialMode: 'silent',
        mechanicsRequired: ['exudate', 'inoculation'] },
    ],
    finalTest: { id: 'p1-test', goal: 'Criar um biofilme funcional na raiz de saída.', requires: [
      { type: 'worldState', key: 'functionalBiofilmCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-2', phase: 2, totalChunks: 40,
    title: 'Rhizobium, nódulo e FBN', theme: 'simbiose',
    mission: 'Estabeleça um nódulo maduro e mantenha a fixação de nitrogênio ativa.',
    newConcepts: ['Rhizobium→nódulo→FBN'], newCommand: null,
    presentations: [{
      id: 'presentation-rhizobium', cardId: 'organism-rhizobium',
      triggerIds: ['organism-rhizobium', 'structure-nodule', 'process-fbn'],
      autoOpenTrigger: 'organism-rhizobium', policy: 'mandatory-first-appearance',
      suppressIndividualCards: true, roamingType: 'rhizobium', debutChunk: 4, poolFromChunk: 9,
      moduleId: 'p2-intro', tetherUntilSeen: true,
      pages: ['quem é/compatibilidade', 'nodulação', 'nódulo maduro', 'FBN e função no jogo'],
    }],
    unlockEvents: [], pathogenDebuts: [],
    segments: [
      { id: 'p2-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['exudate', 'inoculation'] },
      { id: 'p2-intro', kind: 'fixed', from: 4, to: 8, tutorialMode: 'guided',
        debutPresentationIds: ['presentation-rhizobium'], mechanicsRequired: ['exudate', 'inoculation'] },
      { id: 'p2-challenge', kind: 'procedural', from: 9, to: 34, tutorialMode: 'silent', mechanicsRequired: ['exudate', 'inoculation'] },
      { id: 'p2-final', kind: 'final', from: 35, to: 39, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
    ],
    finalTest: { id: 'p2-test', goal: 'Chegar à raiz final com nódulo maduro fixando N₂.', requires: [
      { type: 'worldState', key: 'activeMatureNoduleCount', operator: '>=', value: 1 },
      { type: 'worldState', key: 'totalFixationRate', operator: '>', value: 0.05 },
    ]}, notes: [],
  },

  {
    id: 'phase-3', phase: 3, totalChunks: 40,
    title: 'Azospirillum e arquitetura radicular', theme: 'arquitetura',
    mission: 'Induza raízes laterais e use o salto duplo para alcançar novas rotas.',
    newConcepts: ['Azospirillum→raiz lateral'], newCommand: 'doubleJump',
    presentations: [
      { id: 'presentation-azospirillum', cardId: 'organism-azospirillum',
        triggerIds: ['organism-azospirillum', 'structure-lateral-root'], autoOpenTrigger: 'organism-azospirillum',
        policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        roamingType: 'azospirillum', debutChunk: 4, poolFromChunk: 9,
        moduleId: 'p3-azo-intro', tetherUntilSeen: true,
        pages: ['quem é', 'promoção de crescimento', 'arquitetura radicular', 'raiz lateral no jogo'] },
      { id: 'presentation-double-jump', cardId: 'power-double-jump',
        triggerIds: ['power-double-jump'], autoOpenTrigger: 'power-double-jump',
        policy: 'event-immediate', suppressIndividualCards: false,
        debutChunk: 18, moduleId: 'p3-power-intro',
        pages: ['mecânica de gameplay', 'segundo impulso no ar'] },
    ],
    unlockEvents: [
      { feature: 'azospirillumRoots', eventChunk: 8, afterModule: 'p3-azo-intro', practiceWindowChunks: 3, mandatory: true },
      { feature: 'doubleJump', eventChunk: 20, afterModule: 'p3-power-intro', practiceWindowChunks: 3, mandatory: true },
    ], pathogenDebuts: [],
    segments: [
      { id: 'p3-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
      { id: 'p3-azo-intro', kind: 'fixed', from: 4, to: 8, tutorialMode: 'guided', debutPresentationIds: ['presentation-azospirillum'], mechanicsRequired: ['inoculation'] },
      { id: 'p3-azo-practice', kind: 'procedural', from: 9, to: 17, tutorialMode: 'silent', mechanicsRequired: ['azospirillumRoots'] },
      { id: 'p3-power-intro', kind: 'fixed', from: 18, to: 20, tutorialMode: 'guided', debutPresentationIds: ['presentation-double-jump'], mechanicsRequired: [] },
      { id: 'p3-challenge', kind: 'procedural', from: 21, to: 35, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'azospirillumRoots'] },
      { id: 'p3-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'azospirillumRoots'] },
    ],
    finalTest: { id: 'p3-test', goal: 'Induzir raiz lateral e usar salto duplo.', requires: [
      { type: 'playerUnlock', key: 'doubleJump', operator: '===', value: true },
      { type: 'worldState', key: 'visibleLateralRootCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-4', phase: 4, totalChunks: 40,
    title: 'Micorriza e expansão do solo explorado', theme: 'expansão',
    mission: 'Estabeleça a micorriza, atravesse uma ponte hifal e domine o Dash.',
    newConcepts: ['micorriza→arbúsculo→absorção→ponte'], newCommand: 'dash',
    presentations: [
      { id: 'presentation-mycorrhiza', cardId: 'organism-mycorrhiza',
        triggerIds: ['organism-mycorrhiza', 'structure-arbuscule', 'structure-mycorrhiza-path'],
        autoOpenTrigger: 'organism-mycorrhiza', policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        debutChunk: 4, moduleId: 'p4-myco-intro',
        pages: ['quem é', 'arbúsculo/troca', 'absorção', 'ponte como metáfora de gameplay'] },
      { id: 'presentation-dash', cardId: 'power-dash', triggerIds: ['power-dash'],
        autoOpenTrigger: 'power-dash', policy: 'event-immediate', suppressIndividualCards: false,
        debutChunk: 18, moduleId: 'p4-power-intro', pages: ['mecânica de gameplay', 'impulso horizontal'] },
    ],
    unlockEvents: [
      { feature: 'mycorrhizaStructures', eventChunk: 8, afterModule: 'p4-myco-intro', practiceWindowChunks: 3, mandatory: true },
      { feature: 'dash', eventChunk: 20, afterModule: 'p4-power-intro', practiceWindowChunks: 3, mandatory: true },
    ], pathogenDebuts: [],
    segments: [
      { id: 'p4-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'azospirillumRoots'] },
      { id: 'p4-myco-intro', kind: 'fixed', from: 4, to: 8, tutorialMode: 'guided', debutPresentationIds: ['presentation-mycorrhiza'], mechanicsRequired: ['inoculation'] },
      { id: 'p4-myco-practice', kind: 'procedural', from: 9, to: 17, tutorialMode: 'silent', mechanicsRequired: ['mycorrhizaStructures', 'doubleJump'] },
      { id: 'p4-power-intro', kind: 'fixed', from: 18, to: 20, tutorialMode: 'guided', debutPresentationIds: ['presentation-dash'], mechanicsRequired: ['doubleJump'] },
      { id: 'p4-challenge', kind: 'procedural', from: 21, to: 35, tutorialMode: 'silent', mechanicsRequired: ['dash', 'doubleJump', 'mycorrhizaStructures'] },
      { id: 'p4-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent', mechanicsRequired: ['dash', 'mycorrhizaStructures'] },
    ],
    finalTest: { id: 'p4-test', goal: 'Completar travessia com ponte micorrízica e Dash.', requires: [
      { type: 'playerUnlock', key: 'dash', operator: '===', value: true },
      { type: 'worldState', key: 'functionalMycorrhizaPathCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-5', phase: 5, totalChunks: 40,
    title: 'Ferro e biocontrole fúngico', theme: 'equilíbrio',
    mission: 'Construa reserva de ferro e use Trichoderma contra fungos oportunistas.',
    newConcepts: ['Pseudomonas→sideróforo→ferro', 'oportunista→Trichoderma→micoparasitismo'], newCommand: null,
    presentations: [
      { id: 'presentation-pseudomonas', cardId: 'organism-pseudomonas',
        triggerIds: ['organism-pseudomonas', 'process-siderophore'], autoOpenTrigger: 'organism-pseudomonas',
        policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        roamingType: 'pseudomonas', debutChunk: 4, poolFromChunk: 9,
        moduleId: 'p5-pseudo-intro', tetherUntilSeen: true,
        pages: ['quem é', 'sideróforo', 'Fe³⁺', 'reserva de ferro'] },
      { id: 'presentation-biocontrol', cardId: 'organism-opportunistic-fungus',
        triggerIds: ['organism-opportunistic-fungus', 'organism-trichoderma', 'process-mycoparasitism'],
        autoOpenTrigger: 'organism-opportunistic-fungus', policy: 'mandatory-first-appearance',
        suppressIndividualCards: true, roamingTypes: ['oportunista', 'trichoderma'],
        debutChunk: 18, poolFromChunk: 23, moduleId: 'p5-biocontrol-intro', tetherUntilSeen: true,
        pages: ['oportunista/contaminação', 'Trichoderma', 'crescimento dirigido', 'micoparasitismo'] },
    ],
    unlockEvents: [], pathogenDebuts: [],
    segments: [
      { id: 'p5-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'dash'] },
      { id: 'p5-pseudo-intro', kind: 'fixed', from: 4, to: 8, tutorialMode: 'guided', debutPresentationIds: ['presentation-pseudomonas'], mechanicsRequired: ['inoculation'] },
      { id: 'p5-pseudo-practice', kind: 'procedural', from: 9, to: 17, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
      { id: 'p5-biocontrol-intro', kind: 'fixed', from: 18, to: 22, tutorialMode: 'guided', debutPresentationIds: ['presentation-biocontrol'], mechanicsRequired: ['inoculation'] },
      { id: 'p5-challenge', kind: 'procedural', from: 23, to: 35, tutorialMode: 'silent', mechanicsRequired: ['inoculation', 'doubleJump', 'dash'] },
      { id: 'p5-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
    ],
    finalTest: { id: 'p5-test', goal: 'Atingir reserva de ferro e neutralizar um foco oportunista.', requires: [
      { type: 'worldState', key: 'pseudomonasIronReserve', operator: '>=', value: 1 },
      { type: 'worldState', key: 'neutralizedOpportunisticFungusCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-6', phase: 6, totalChunks: 40,
    title: 'Rhizoctonia, saúde da raiz e Pulso', theme: 'patologia',
    mission: 'Controle Rhizoctonia, recupere a sustentação da raiz e libere o Pulso.',
    newConcepts: ['Rhizoctonia→lesão→saúde/recuperação'], newCommand: 'pulse',
    presentations: [
      { id: 'presentation-root-health', cardId: 'organism-rhizoctonia',
        triggerIds: ['organism-rhizoctonia', 'process-root-health', 'process-root-recovery', 'process-root-collapse'],
        autoOpenTrigger: 'organism-rhizoctonia', policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        debutChunk: 4, moduleId: 'p6-rhizo-intro',
        pages: ['Rhizoctonia', 'lesão progressiva', 'estados de saúde', 'recuperação/sustentação'] },
      { id: 'presentation-pulse', cardId: 'power-pulse',
        triggerIds: ['organism-phosphate-solubilizer', 'power-pulse'], autoOpenTrigger: 'power-pulse',
        policy: 'event-immediate', suppressIndividualCards: true,
        debutChunk: 18, moduleId: 'p6-pulse-intro',
        pages: ['cristal de fosfato', 'solubilizador como âncora', 'Pulso como poder de gameplay'] },
    ],
    unlockEvents: [
      { feature: 'pulse', eventChunk: 20, afterModule: 'p6-pulse-intro', practiceWindowChunks: 3, mandatory: true },
    ],
    pathogenDebuts: [{ pathogen: 'rhizoctonia', fromChunk: 4, presentationId: 'presentation-root-health' }],
    segments: [
      { id: 'p6-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'dash', 'inoculation'] },
      { id: 'p6-rhizo-intro', kind: 'fixed', from: 4, to: 10, tutorialMode: 'guided', debutPresentationIds: ['presentation-root-health'], mechanicsRequired: ['inoculation'] },
      { id: 'p6-rhizo-practice', kind: 'procedural', from: 11, to: 17, tutorialMode: 'silent', mechanicsRequired: ['inoculation', 'doubleJump', 'dash'] },
      { id: 'p6-pulse-intro', kind: 'fixed', from: 18, to: 20, tutorialMode: 'guided', debutPresentationIds: ['presentation-pulse'], mechanicsRequired: [] },
      { id: 'p6-challenge', kind: 'procedural', from: 21, to: 35, tutorialMode: 'silent', mechanicsRequired: ['pulse', 'doubleJump', 'dash', 'inoculation'] },
      { id: 'p6-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent', mechanicsRequired: ['pulse'] },
    ],
    finalTest: { id: 'p6-test', goal: 'Recuperar uma raiz e quebrar o cristal da saída.', requires: [
      { type: 'playerUnlock', key: 'pulse', operator: '===', value: true },
      { type: 'worldState', key: 'recoveredRootCount', operator: '>=', value: 1 },
      { type: 'worldState', key: 'brokenCrystalCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-7', phase: 7, totalChunks: 40,
    title: 'Meloidogyne: infecção, reprodução e sequela', theme: 'infestação',
    mission: 'Impeça novas penetrações, neutralize massas de ovos e preserve uma raiz.',
    newConcepts: ['J2→penetração→galha', 'fêmea→massa de ovos→sequela'], newCommand: null,
    presentations: [
      { id: 'presentation-meloidogyne-infection', cardId: 'organism-meloidogyne-j2',
        triggerIds: ['organism-meloidogyne-j2', 'structure-gall'], autoOpenTrigger: 'organism-meloidogyne-j2',
        policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        debutChunk: 4, moduleId: 'p7-infection-intro',
        pages: ['J2', 'busca da raiz', 'penetração/migração', 'galha'] },
      { id: 'presentation-meloidogyne-reproduction', cardId: 'organism-meloidogyne-female',
        triggerIds: ['organism-meloidogyne-female', 'structure-egg-mass'], autoOpenTrigger: 'organism-meloidogyne-female',
        policy: 'mandatory-first-appearance', suppressIndividualCards: true,
        debutChunk: 18, moduleId: 'p7-reproduction-intro',
        pages: ['fêmea adulta', 'oviposição', 'massa/eclosão', 'saúde máxima/cicatriz'] },
    ],
    unlockEvents: [],
    pathogenDebuts: [{ pathogen: 'meloidogyne', fromChunk: 4, presentationId: 'presentation-meloidogyne-infection' }],
    segments: [
      { id: 'p7-warmup', kind: 'procedural', from: 0, to: 3, tutorialMode: 'silent', mechanicsRequired: ['doubleJump', 'dash', 'pulse'] },
      { id: 'p7-infection-intro', kind: 'fixed', from: 4, to: 10, tutorialMode: 'guided', debutPresentationIds: ['presentation-meloidogyne-infection'], mechanicsRequired: [] },
      { id: 'p7-infection-practice', kind: 'procedural', from: 11, to: 17, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
      { id: 'p7-reproduction-intro', kind: 'fixed', from: 18, to: 23, tutorialMode: 'guided', debutPresentationIds: ['presentation-meloidogyne-reproduction'], mechanicsRequired: [] },
      { id: 'p7-challenge', kind: 'procedural', from: 24, to: 35, tutorialMode: 'silent', mechanicsRequired: ['inoculation', 'doubleJump', 'dash', 'pulse'] },
      { id: 'p7-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent', mechanicsRequired: ['inoculation'] },
    ],
    finalTest: { id: 'p7-test', goal: 'Neutralizar uma massa de ovos e preservar uma raiz.', requires: [
      { type: 'worldState', key: 'neutralizedEggMassCount', operator: '>=', value: 1 },
      { type: 'worldState', key: 'preservedRootCount', operator: '>=', value: 1 },
    ]}, notes: [],
  },

  {
    id: 'phase-8', phase: 8, totalChunks: 40,
    title: 'Ecossistema integrado', theme: 'síntese',
    mission: 'Proteja, controle, recupere e atravesse usando tudo o que aprendeu.',
    newConcepts: [], newCommand: null,
    presentations: [], unlockEvents: [],
    pathogenDebuts: [
      { pathogen: 'rhizoctonia', fromChunk: 0, presentationId: null },
      { pathogen: 'meloidogyne', fromChunk: 0, presentationId: null },
    ],
    segments: [
      { id: 'p8-integrated', kind: 'procedural', from: 0, to: 35, tutorialMode: 'silent',
        mechanicsRequired: ['doubleJump', 'dash', 'pulse', 'inoculation'] },
      { id: 'p8-final', kind: 'final', from: 36, to: 39, tutorialMode: 'silent',
        mechanicsRequired: ['doubleJump', 'dash', 'pulse', 'inoculation'] },
    ],
    finalTest: { id: 'p8-test', goal: 'Concluir o desafio integrado com pontuação mínima.', requires: [
      { type: 'worldState', key: 'ecologicalScore', operator: '>=', value: 1 },
      { type: 'worldState', key: 'reachedFinalRoot', operator: '===', value: true },
    ]},
    notes: ['Ralstonia fica para expansão pós-piloto.', 'Nenhum cartão holográfico automático nesta fase.'],
  },
];

export const campaignManifest = Object.freeze(phases);

export function getPhaseManifest(phase) {
  return campaignManifest.find(entry => entry.phase === phase) || null;
}

export function getSegmentAt(phase, chunkIndex) {
  return getPhaseManifest(phase)?.segments.find(s => chunkIndex >= s.from && chunkIndex <= s.to) || null;
}

export function getTutorialModeAt(phase, chunkIndex) {
  return getSegmentAt(phase, chunkIndex)?.tutorialMode || 'disabled';
}

export function getPresentationById(id) {
  for (const phase of campaignManifest) {
    const found = phase.presentations.find(p => p.id === id);
    if (found) return found;
  }
  return null;
}

export function getPresentationForTrigger(triggerId) {
  for (const phase of campaignManifest) {
    const found = phase.presentations.find(p => p.triggerIds.includes(triggerId));
    if (found) return found;
  }
  return null;
}

function roamingTypesOf(presentation) {
  if (presentation.roamingType) return [presentation.roamingType];
  if (Array.isArray(presentation.roamingTypes)) return presentation.roamingTypes.slice();
  return [];
}

export function getProceduralPoolAt(phase, chunkIndex) {
  const types = new Set();
  for (const entry of campaignManifest) {
    if (entry.phase > phase) break;
    for (const presentation of entry.presentations) {
      const roaming = roamingTypesOf(presentation);
      if (!roaming.length) continue;
      if (entry.phase < phase || (entry.phase === phase && chunkIndex >= presentation.poolFromChunk)) {
        roaming.forEach(type => types.add(type));
      }
    }
  }
  return [...types];
}

export function getPathogensAt(phase, chunkIndex) {
  const active = new Set();
  for (const entry of campaignManifest) {
    if (entry.phase > phase) break;
    for (const debut of entry.pathogenDebuts) {
      if (entry.phase < phase || chunkIndex >= debut.fromChunk) active.add(debut.pathogen);
    }
  }
  return [...active];
}

export function getPersistentUnlocksBeforePhase(phase) {
  const active = Object.fromEntries(CAMPAIGN_UNLOCKS.map(flag => [flag, false]));
  for (const entry of campaignManifest) {
    if (entry.phase >= phase) break;
    for (const event of entry.unlockEvents) active[event.feature] = true;
  }
  return active;
}

export function getAvailableUnlocksAt(phase, chunkIndex) {
  const active = getPersistentUnlocksBeforePhase(phase);
  const entry = getPhaseManifest(phase);
  if (!entry) return active;
  for (const event of entry.unlockEvents) {
    if (event.eventChunk < chunkIndex) active[event.feature] = true;
  }
  return active;
}

export function getRequiredPracticeAbilityAt(phase, chunkIndex) {
  const entry = getPhaseManifest(phase);
  if (!entry) return null;
  for (const event of entry.unlockEvents) {
    const start = event.eventChunk + 1;
    const end = event.eventChunk + Math.max(0, event.practiceWindowChunks || 0);
    if (chunkIndex >= start && chunkIndex <= end) return event.feature;
  }
  return null;
}

export function getTetheredDebutsAt(phase, chunkIndex) {
  const entry = getPhaseManifest(phase);
  const segment = getSegmentAt(phase, chunkIndex);
  if (!entry || !segment || segment.kind !== 'fixed') return [];
  return entry.presentations
    .filter(p => p.tetherUntilSeen && segment.debutPresentationIds?.includes(p.id))
    .flatMap(p => roamingTypesOf(p).map(type => ({ type, cardId: p.cardId, presentationId: p.id })));
}

export function globalPresentationOrder() {
  return campaignManifest
    .flatMap(entry => entry.presentations.map(p => ({ phase: entry.phase, ...p })))
    .sort((a, b) => a.phase - b.phase || a.debutChunk - b.debutChunk);
}

const VALID_FINAL_TYPES = new Set(['worldState', 'playerUnlock']);
const VALID_OPERATORS = new Set(['===', '!==', '>', '>=', '<', '<=']);

export function validateCampaignManifest({
  knownCardIds = null,
  knownRoamingTypes = ECOLOGY_ROAMING_TYPES,
  knownPathogens = PATHOGEN_SYSTEMS,
  knownUnlocks = CAMPAIGN_UNLOCKS,
} = {}) {
  const errors = [];
  const phaseIds = new Set();
  const presentationIds = new Set();

  campaignManifest.forEach((phase, expectedPhase) => {
    if (phase.phase !== expectedPhase) errors.push(`Fase fora de ordem: ${phase.phase}; esperado ${expectedPhase}.`);
    if (phaseIds.has(phase.id)) errors.push(`ID de fase duplicado: ${phase.id}.`);
    phaseIds.add(phase.id);
    if (phase.newConcepts.length > 2) errors.push(`${phase.id}: mais de dois grupos conceituais.`);

    const coverage = new Array(phase.totalChunks).fill(0);
    for (const segment of phase.segments) {
      if (!TUTORIAL_MODES.includes(segment.tutorialMode)) errors.push(`${phase.id}/${segment.id}: tutorialMode inválido.`);
      if (segment.from < 0 || segment.to >= phase.totalChunks || segment.from > segment.to) {
        errors.push(`${phase.id}/${segment.id}: intervalo inválido.`); continue;
      }
      for (let i = segment.from; i <= segment.to; i++) coverage[i]++;
    }
    coverage.forEach((count, chunk) => {
      if (count === 0) errors.push(`${phase.id}: chunk ${chunk} sem segmento.`);
      if (count > 1) errors.push(`${phase.id}: chunk ${chunk} sobreposto.`);
    });

    for (const p of phase.presentations) {
      if (presentationIds.has(p.id)) errors.push(`Apresentação duplicada: ${p.id}.`);
      presentationIds.add(p.id);
      if (!PRESENTATION_POLICIES.includes(p.policy)) errors.push(`${p.id}: policy inválida.`);
      if (!p.triggerIds.includes(p.autoOpenTrigger)) errors.push(`${p.id}: autoOpenTrigger fora de triggerIds.`);
      if (knownCardIds && !knownCardIds.includes(p.cardId)) errors.push(`${p.id}: cardId inexistente ${p.cardId}.`);
      for (const type of roamingTypesOf(p)) {
        if (!knownRoamingTypes.includes(type)) errors.push(`${p.id}: roaming type desconhecido ${type}.`);
      }
      if (roamingTypesOf(p).length && !Number.isInteger(p.poolFromChunk)) errors.push(`${p.id}: falta poolFromChunk.`);
    }

    for (const event of phase.unlockEvents) {
      if (!knownUnlocks.includes(event.feature)) errors.push(`${phase.id}: unlock desconhecido ${event.feature}.`);
      if (event.eventChunk < 0 || event.eventChunk >= phase.totalChunks) errors.push(`${phase.id}: eventChunk inválido.`);
      if (!phase.segments.some(s => s.id === event.afterModule)) errors.push(`${phase.id}: afterModule inexistente ${event.afterModule}.`);
    }

    for (const debut of phase.pathogenDebuts) {
      if (!knownPathogens.includes(debut.pathogen)) errors.push(`${phase.id}: patógeno desconhecido ${debut.pathogen}.`);
    }

    for (const condition of phase.finalTest.requires) {
      if (!VALID_FINAL_TYPES.has(condition.type)) errors.push(`${phase.id}: tipo de condição inválido.`);
      if (!VALID_OPERATORS.has(condition.operator)) errors.push(`${phase.id}: operador inválido.`);
    }

    for (const segment of phase.segments) {
      for (const mechanic of segment.mechanicsRequired || []) {
        if (!knownUnlocks.includes(mechanic)) continue;
        for (let chunk = segment.from; chunk <= segment.to; chunk++) {
          if (!getAvailableUnlocksAt(phase.phase, chunk)[mechanic]) {
            errors.push(`${phase.id}/${segment.id}: ${mechanic} exigido antes do unlock no chunk ${chunk}.`);
            break;
          }
        }
      }
    }
  });

  return errors;
}
