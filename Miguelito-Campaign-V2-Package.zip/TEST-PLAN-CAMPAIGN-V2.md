# Plano de testes — Campanha didática v2

## Manifesto

- fases e IDs ordenados/únicos;
- segmentos cobrem todos os chunks sem lacunas ou sobreposição;
- no máximo dois grupos e um comando por fase;
- IDs, tipos, patógenos e unlocks reais;
- nenhuma mecânica antes do unlock.

## Primeira aparição

- estreia normal abre cartão imediatamente;
- aparição inesperada ignora pacing e emite diagnóstico;
- nenhum instante de jogo com organismo novo inexplicado.

## Agrupamento

Testar:

- Bacillus/biofilme;
- Rhizobium/nódulo/FBN;
- micorriza/arbúsculo/ponte;
- Pseudomonas/sideróforo;
- oportunista/Trichoderma/micoparasitismo;
- Rhizoctonia/saúde/recuperação;
- J2/galha;
- fêmea/massa de ovos.

Gatilhos derivados não devem abrir cartões individuais.

## Pacing

- 0,9 viewport ou 60 s para apresentações espaçadas;
- organismo novo e poder ignoram a trava;
- GUIA não altera o estado de pacing.

## Modos

- guided pausa;
- silent registra sem pausar;
- disabled não registra automaticamente.

## Gating de habilidades

Para muitas seeds:

- nenhum cristal antes do Pulso;
- nenhum requisito de Pulso antes do unlock;
- nenhum vão de Dash antes do Dash;
- nenhum requisito de salto duplo antes do unlock;
- nenhuma ponte antes da micorriza;
- nenhuma raiz lateral antes do Azospirillum.

## Persistência

Testar morte, checkpoint, reload, avanço de fase e restauração de unlocks realmente obtidos.

## Patógenos

- Rhizoctonia só na Fase 6/chunk de estreia;
- Meloidogyne só na Fase 7/chunk de estreia;
- ordem J2→galha→fêmea→massa;
- Ralstonia ausente do MVP.

## Provas

Cartão visto sem ação realizada deve falhar.

## Playtest pedagógico

Observar ritmo, clareza, necessidade de reler, sobrecarga nas fases 5–7, duração, abandono e pontos de bloqueio.
